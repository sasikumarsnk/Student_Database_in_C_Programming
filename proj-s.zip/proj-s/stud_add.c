#include"header.c"

void stud_add(STD **ptr,int *roll)
{
	STD *student = (STD *)malloc(sizeof(STD));//create every node for students
	/*Adding Student Information*/
	printf("Enter your Name : ");
	scanf(" %[^\n]",student->name);
	printf("Enter your Mark : ");
	scanf("%hd",&(student->mark));
	++(*roll);//increment roll_no for every addmission
	student->roll_no = *roll;
	/*Store into Singly Linked List */
	student->next=0;
	if(*ptr==0)
	{
		*ptr=student;
		return;
	}
	STD *end =(STD *)malloc(sizeof(STD));
	end = *ptr;
	while(end->next!=0)
		end=end->next;
	end->next=student;
}
