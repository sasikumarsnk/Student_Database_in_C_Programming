/*includings header files */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
/*------------------------- */


/*Structure for student Record*/
typedef struct std
{
	unsigned int roll_no;
	char name[40];
	unsigned short int mark;
	struct std *next;
}STD;

/*-------------------------------- */

/*Function Defintions */
void stud_add(STD **,int *);
void stud_show(STD *);
void stud_del(STD **);
void del_roll(STD **,unsigned int);
void del_name(STD **,char *);
void stud_mod(STD *);
void mod_roll(STD *,unsigned int);
void mod_name(STD *,char *);
void stud_save(STD *,int);
void stud_update(STD **,int *);
STD *create_node(void);
void del_all(STD **,int *);
void stud_rev(STD **);
int stud_count(STD *);
void sort_fltr(STD **);
STD *duplicate(STD *);
void sll_list(STD *);
void ttl_list(STD *);
void nll_list(STD *);
/*------------------------------*/


