#include"header.c"

void stud_rev(STD **ptr)
{
	STD *t_hptr = duplicate(*ptr);
	int c=stud_count(t_hptr),i;
	char op;
	STD **p =(STD **)malloc(c*sizeof(STD*));
	for(i=0;i<c;i++)
	{
		p[i]=t_hptr;
		t_hptr=(t_hptr)->next;
	}	
	p[0]->next=0;
	for(i=1;i<c;i++)
		p[i]->next=p[i-1];
	t_hptr=p[c-1];
	stud_show(t_hptr);
	printf("Reversed Sucessfully!\n");
	printf("Do you want to save reversed data permantatly\n");
	printf("---------------\n");
	printf("|***OPTIONS***|\n");
	printf("---------------\n");
	printf("| Y : yes     |\n");
	printf("| N : no      |\n");
	printf("---------------\n");
	printf("Enter your option : ");
	scanf(" %c",&op);
	switch(op)
	{
		case 'Y':
			*ptr=t_hptr;
			break;
		default:
			printf("Data Not modified\n");
	}
}

int stud_count(STD *ptr)
{
	int count=0;
	while(ptr!=0)
	{
		++count;
		ptr=ptr->next;
	}
	return count;
}
