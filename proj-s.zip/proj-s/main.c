#include"header.c"
int main()
{
	int roll=0;
	STD *hptr = 0;
	char op;
	stud_update(&hptr,&roll);
	while(1)
	{ 
		/*Displaying Options for operations */
		printf("-------------------------------------\n");
		printf("|**********Student Record***********|\n");
		printf("|-----------------------------------|\n");
		printf("| A : add new record                |\n");
		printf("| D : delete a record               |\n");
		printf("| S : show the list                 |\n");
		printf("| M : modify a record               |\n");
		printf("| E : save and exit                 |\n");
		printf("| T : sort the list                 |\n");
		printf("| L : delete all record             |\n");
		printf("| R : reverse the list              |\n");
		printf("-------------------------------------\n");
		printf("Enter your option : ");
		scanf(" %c",&op);
		switch(op)
		{
			case 'A':
				stud_add(&hptr,&roll);
				break;
			case 'S':
				stud_show(hptr);
				break;
			case 'D':
				stud_del(&hptr);
				break;
			case 'M':
				stud_mod(hptr);
				break;
			case 'E':
				stud_save(hptr,roll);
				return 0;
			case 'L':
				del_all(&hptr,&roll);
				break;
			case 'R':
				stud_rev(&hptr);
				break;
			case 'T':
				sort_fltr(&hptr);
				break;
			default:
				printf("Invalid Option\n");
				break;
		}
	}
}
