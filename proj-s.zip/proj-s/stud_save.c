#include"header.c"

void stud_save(STD *ptr,int roll)
{
	FILE *fp = fopen("stud_text.txt","w");
	while(ptr!=0)
	{
		fprintf(fp,"%c\n%d\n%s\n%d\n",'Y',ptr->roll_no,ptr->name,ptr->mark);
		ptr=ptr->next;
	}
	fprintf(fp,"N\n");
	fprintf(fp,"%d\n",roll);
	printf("Save Sucessfully!\n");
}
