#include"header.c"

void del_all(STD **ptr,int *roll)
{
	STD *del = (STD *)malloc(sizeof(STD));
	del = *ptr;
	while(*ptr!=0)
	{
		del=*ptr;
		*ptr = (*ptr)->next;
		free(del);
	}
	*ptr=0;
	if(*roll != 0)
		*roll=0;
	printf("All Student Record Deleted\n");
}
