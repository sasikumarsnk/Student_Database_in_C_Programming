#include"header.c"
void stud_update(STD **ptr,int *roll)
{
	FILE *fp = fopen("stud_text.txt","r");
	char op;
	fscanf(fp,"%c",&op);
	STD *stud = (STD *)malloc(sizeof(STD));
	STD *end = (STD *)malloc(sizeof(STD));
	while(op!='N')
	{
		stud=create_node();
		fscanf(fp,"%d",&stud->roll_no);
		fscanf(fp," %[^\n]",stud->name);
		fscanf(fp,"%hd",&stud->mark);
		fscanf(fp," %c",&op);
		stud->next=0;
		if(*ptr==0)
		{
			*ptr=stud;
			continue;
		}
		end = *ptr;
		while(end->next !=0)
			end=end->next;
		end->next = stud;
	}
	*roll = stud->roll_no;
}

STD* create_node()
{
	STD *user = (STD *)malloc(sizeof(STD));
	return user;
}
