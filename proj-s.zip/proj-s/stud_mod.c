#include"header.c"

void stud_mod(STD *ptr)
{
	char op;
	unsigned int roll;
	char name[20];
	printf("-------------------\n");
	printf("|**Enter option **|\n");
	printf("-------------------\n");
	printf("| R : Roll no     |\n");
	printf("| N : Name        |\n");
	printf("-------------------\n");
	printf("Enter your option : ");
	scanf(" %c",&op);
	switch(op)
	{
		case'R':
			printf("Enter your Roll_no : ");
			scanf("%d",&roll);
			mod_roll(ptr,roll);
			break;
		case'N':
			printf("Enter your name : ");
			scanf(" %[^\n]",name);
			mod_name(ptr,name);
			break;
		default:
			printf("Invalid Option\n");
			break;
	}
}

void mod_roll(STD *ptr,unsigned int roll_no)
{
	STD *mod = (STD *)malloc(sizeof(STD));
	STD *check = (STD *)malloc(sizeof(STD));
	char op;
	char new_name[20];
	unsigned int roll,mark;
	mod = ptr;
	check = ptr;
	while(mod!=0 && mod->roll_no!=roll_no)
		mod = mod->next;
	if(mod==0)
	{
		printf("Invalid roll no\n");
		return;
	}
	printf("Welcome %s!\n",mod->name);
	printf("What you want to modify?\n");
	printf("---------------\n");
	printf("|***OPTIONS***|\n");
	printf("---------------\n");
	printf("| N : Name    |\n");
       	printf("| R : RollNo  |\n");
	printf("| M : Marks   |\n");
	printf("---------------\n");	
	printf("Enter Your option : ");
	scanf(" %c",&op);
	switch(op)
	{
		case'N':
			printf("Your Existing Name %s\n",mod->name);
			printf("Enter your new Name : ");
			scanf(" %[^\n]",new_name);
			strcpy(mod->name,new_name);
			printf("Name Updated Sucessfully!\n");
			break;
		case'R':
			printf("Your Existing Roll_no %d\n",mod->roll_no);
			printf("Enter your new Roll_no : ");
			scanf("%d",&roll);
			while(check!=0 && check->roll_no!=roll)
				check=check->next;
			if(check->roll_no==roll)
			{
				printf("Roll no already exits\n");
				return;
			}
			mod->roll_no = roll;
			printf("Roll no updated sucessfully!\n");
			break;
		case'M':
			printf("Enter your mark : ");
			scanf("%d",&mark);
			mod->mark=mark;
			printf("Mark updated sucessfully!\n");
			break;
		default:
			printf("Invalid options!\n");
			break;
	}
}


void mod_name(STD *ptr,char *name)
{
	STD *mod = (STD *)malloc(sizeof(STD));
	STD *check =(STD *)malloc(sizeof(STD));
	unsigned int roll,mark;
	char str[20];
	char op;
	mod = ptr;
	check = ptr;
	while(mod!=0 && strcmp(mod->name,name))
		mod=mod->next;
	if(!mod)
	{
		printf("Invalid Name !");
		return;
	}
	printf("Welcome %s!\n",mod->name);
	printf("---------------\n");
	printf("|***OPTIONS***|\n");
	printf("---------------\n");
	printf("| N : Name    |\n");
	printf("| R : Roll no |\n");
	printf("| M : Mark    |\n");
	printf("---------------\n");
	printf("Enter your Options : ");
	scanf(" %c",&op);
	switch(op)
	{
		case'N':
			printf("Your Existing Name %s\n",mod->name);
			printf("Enter your new Name : ");
			scanf(" %[^\n]",str);
			strcpy(mod->name,str);
			printf("Name updated Sucessfully!\n");
			break;
		case'R':
			printf("Your Existing roll no %d",mod->roll_no);
			printf("Enter your new roll no : ");
			scanf("%d",&roll);
			while(check!=0 && check->roll_no!=roll)
				check=check->next;
			if(check->roll_no == roll)
			{
				printf("your roll no already exists\n");
				return;
			}
			mod->roll_no = roll;
			printf("Roll No sucessfully updated!\n");
			break;
		case'M':
			printf("Enter your mark : ");
			scanf("%d",&mark);
			mod->mark = mark;
			printf("Mark updated sucessfully\n");
			break;
		default:
			printf("Invalid options\n");
			break;
	}
}

