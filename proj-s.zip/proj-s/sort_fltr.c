#include"header.c"

void sort_fltr(STD **ptr)
{
	char op;
	STD *dup=duplicate(*ptr);
	printf("----------------------------\n");
	printf("|*********OPTIONS**********|\n");
	printf("----------------------------\n");
	printf("| S : slow leaner list     |\n");
	printf("| T : top  list            |\n");
	printf("| N : name list            |\n");
	printf("----------------------------\n");
	printf("Enter you options : ");
	scanf(" %c",&op);
	switch(op)
	{
		case'S':
			sll_list(dup);
			break;
		case'T':
			ttl_list(dup);
			break;
		case'N':
			nll_list(dup);
			break;
		default:
			printf("Invalid Option\n");
			break;
	}
}


STD *duplicate(STD *ptr)
{
	STD *node;
	if(ptr==0)
		return NULL;

	node = create_node();
	node->roll_no = ptr->roll_no;
	strcpy(node->name,ptr->name);
	node->mark = ptr->mark;
	node->next =duplicate(ptr->next);
	return node;
}

void sll_list(STD *ptr)
{
	int count = stud_count(ptr);
	int tot_stud=0,space;
	char op;
	char f_name[20];
	STD *dup = ptr;
	STD **data = (STD **)malloc(count * sizeof(STD *));
	for(int i=0;i<count;i++)
	{
		if(dup->mark <= 50)
			++tot_stud;
		data[i]=dup;
		dup=dup->next;
	}
	printf(" %d\n",tot_stud);

	printf("Slow leaner list\n");
	printf("------------------------\n");
	printf("|Name            Marks |\n");
	printf("------------------------\n");
	for(int i=0;i<count;i++)
	{
		if(data[i]->mark <= 50)
		{
			printf("| ");
			space=printf("%s",data[i]->name);
			for(int j=0;j<(16-space);j++)
				printf(" ");
			printf("%d   |\n",data[i]->mark);
		}
	}
	printf("------------------------\n");
	printf("\n");
	printf("Do you want to generate file(Y/N)\n");
	scanf(" %c",&op);
	switch(op)
	{
		case'Y':
			printf("Enter your File Name : ");
			scanf("%s",f_name);
			FILE *fp = fopen(f_name,"w");
			fprintf(fp,"-----------------------------\n");
			fprintf(fp,"|******Slow leaner list*****|\n");
		       	fprintf(fp,"-----------------------------\n");
			fprintf(fp,"| Name          Marks       |\n");
			fprintf(fp,"-----------------------------\n");
			for(int i=0;i<count;i++)
			{
				if(data[i]->mark <=50)
				{
					space = fprintf(fp,"| %s",data[i]->name);
					for(int j=0;j<(16-space);j++)
						fprintf(fp," ");
					fprintf(fp," %d         |\n",data[i]->mark);
				}
			}
			fprintf(fp,"-----------------------------\n");
			fclose(fp);
			printf("File generated\n");
			break;
		default:
			printf("File not generated\n");
			break;
		
	}
}


void ttl_list(STD *ptr)
{
	int count = stud_count(ptr);
	int space;
	char op,f_name[20];
	STD **data = (STD **)malloc(count * sizeof(STD *));
	STD *temp = ptr;
	for(int i=0;i<count;i++)
	{
		data[i] = temp;
		temp=temp->next;
	}
	for(int i=0;i<count-1;i++)
	{
		for(int j=i+1;j<count;j++)
		{

			if(data[i]->mark < data[j]->mark)
			{
				temp = data[i];
				data[i] = data[j];
				data[j] = temp;
			}
		}
	}
	printf("Sorted based on marks\n");
	printf("------------------------\n");
	printf("| Name            Mark |\n");
	printf("------------------------\n");
	for(int i=0;i<count;i++)
	{
		printf("| ");
		space = printf("%s",data[i]->name);
		for(int i=0;i<(16-space);i++)
			printf(" ");
		space = printf(" %d  ",data[i]->mark);
		for(int i=0;i<(6-space);i++)
			printf(" ");
		printf("|\n");
	}
	printf("------------------------\n");

	printf("Do you want generate file(Y/N) : ");
	scanf(" %c",&op);
	switch(op)
	{
		case'Y':
			printf("Enter file Name : ");
			scanf("%s",f_name);
			FILE *fp = fopen(f_name,"w");
			fprintf(fp,"----------------------------\n");
			fprintf(fp,"| Top Student Mark list    |\n");
			fprintf(fp,"----------------------------\n");
			fprintf(fp,"| Name             Mark    |\n");
			fprintf(fp,"----------------------------\n");
			for(int i=0;i<count;i++)
			{
				fprintf(fp,"| ");
				space = fprintf(fp,"%s",data[i]->name);
				for(int i=0;i<(16-space);i++)
					fprintf(fp," ");
				space = fprintf(fp," %d",data[i]->mark);
				for(int i=0;i<(8-space);i++)
					fprintf(fp," ");
				fprintf(fp,"|\n");
			}
			fprintf(fp,"----------------------------\n");
			fclose(fp);
			printf("File generated sucessfully!\n");
			break;
		default:
			printf("File not generated!\n");
			break;
	}

}

void nll_list(STD *ptr)
{
	int count = stud_count(ptr);
	int space;
	char op,f_name[20];
	STD *temp;
	STD **data = (STD **)malloc(sizeof(STD *) * count);
	for(int i=0;i<count;i++)
	{
		data[i] = ptr;
		ptr=ptr->next;
	}
	for(int i=0;i<count-1;i++)
	{
		for(int j=i+1;j<count;j++)
		{
			if(strcmp(data[i]->name,data[j]->name)>0)
			{
				temp = data[i];
				data[i] = data[j];
				data[j] = temp;
			}
		}
	}
	printf("--------------------------\n");
	printf("| Name list              |\n");
	printf("--------------------------\n");
	for(int i=0;i<count;i++)
	{
		printf("| ");
		space = printf("%s",data[i]->name);
		for(int i=0;i<(23-space);i++)
			printf(" ");
		printf("|\n");
	}
	printf("--------------------------\n");

	printf("Do you want to generate file?(Y/N) : ");
	scanf(" %c",&op);
	switch(op)
	{
		case'Y':
			printf("Enter file name : ");
			scanf("%s",f_name);
			FILE *fp = fopen(f_name,"w");
			fprintf(fp,"--------------------------\n");
			fprintf(fp,"| Name list              |\n");
			fprintf(fp,"--------------------------\n");
			for(int i=0;i<count;i++)
			{
				fprintf(fp,"| ");
				space = fprintf(fp,"%s",data[i]->name);
				for(int i=0;i<(23-space);i++)
					fprintf(fp," ");
				fprintf(fp,"|\n");
			}
			fprintf(fp,"--------------------------\n");
			printf("File generated !\n");
			fclose(fp);
			break;
		default:
			printf("File not generated!\n");
			break;
	}
}
