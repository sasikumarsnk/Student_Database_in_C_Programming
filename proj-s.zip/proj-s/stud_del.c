#include"header.c"

void stud_del(STD **ptr)
{
	char op;
	unsigned int roll;
	char name[20];
	printf("-------------------\n");
	printf("|**Enter option **|\n");
	printf("-------------------\n");
	printf("| R : Roll no     |\n");
	printf("| N : Name        |\n");
	printf("-------------------\n");
	printf("Enter your option : ");
	scanf(" %c",&op);
	switch(op)
	{
		case'R':
			printf("Enter your Roll_No : ");
			scanf(" %d",&roll);
			del_roll(ptr,roll);
			break;
		case'N':
			printf("Enter your Name : ");
			scanf(" %[^\n]",name);
			del_name(ptr,name);

	}
}
void del_roll(STD **ptr,unsigned int roll)
{
	STD *del = (STD *)malloc(sizeof(STD));
	STD *prev = (STD *)malloc(sizeof(STD));
	del = *ptr;
	while(del!=0 && del->roll_no!=roll)
	{
		prev = del;
		del=del->next;
	}
	if(del==0)
	{
		printf("Invalid Student Roll NO!\n");
		return;
	}
	if(*ptr == del)
		*ptr=del->next;
	else
		prev->next = del->next;
	printf("Student %s removed sucessfully!\n",del->name);
	free(del);
}
void del_name(STD **ptr,char *name)
{
	STD *del = (STD *)malloc(sizeof(STD));
	STD *prev = (STD *)malloc(sizeof(STD));
	del = *ptr;
	while(del!=0 && strcmp(name,del->name))
	{
		prev = del;
		del = del->next;
	}
	if(del==0)
	{
		printf("Invalid Student Name\n");
		return;
	}
	if(*ptr==del)
		*ptr = del->next;
	else
		prev->next = del->next;
	printf("Student %s removed sucessfully!\n",del->name); 
	free(del);
}
