#include"header.c"

void stud_show(STD *ptr)
{
	int space,i;
	printf("------------------------------\n");
	printf("|Roll No   Name       Marks  |\n");
	printf("------------------------------\n");
	while(ptr!=0)
	{
		space=printf("| %d",ptr->roll_no);
		for(i=0;i<(8-space);i++)
			printf(" ");
		space=printf("%s",ptr->name);
		for(i=0;i<(16-space);i++)
			printf(" ");
		space=printf("%d",ptr->mark);
		for(i=0;i<(5-space);i++)
			printf(" ");
		printf("|\n");
		ptr=ptr->next;
	}
	printf("------------------------------\n");
}
